const http = require("http");
const { request } = require("https");
const url = require("url");

//url.parse()  function

http.createServer((request,Response) =>{
    console.log(request.url);
   const urlOb =  url.parse(request.url,true); // using perse mechanism
   console.log(urlOb)

   console.log(urlOb.query.keywords)

}).listen(8082);