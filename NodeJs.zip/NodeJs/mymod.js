const findAvg = (a, b, c) => {
    console.log("finding")
    return (a + b + c) / 3;
};
module.exports = findAvg;
