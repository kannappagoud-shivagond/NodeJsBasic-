
const myfun = require("./mymod")
 const avg = myfun(12, 45, 63);
console.log("avg is " + avg);

console.log("this is first node js node");
console.log("i m going excute java script with node");
let a = 5;
const b = 21;
var c = 11;
console.log(a + b + c);
console.log("run using runner");
