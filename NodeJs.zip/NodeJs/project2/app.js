//console.log("project stared.")
// let a=45;
// let b=12;
// console.log(a+b)

//Email send:

const mailer=require('nodemailer')

let transport=mailer.createTransport({
    auth:{
        user:'kannushivagond@gmail.com',
        pass:''
    }
})

let messageOb={
    from:'kannushivagond@gmail.com',
    to:'kannappagoud22@gmail.com',
    subject:'Email using NODE JS',
    text:'this mail is send using node js'
}

transport.sendMail(messageOb,(error,info) => {
    if(error)
    {
        console.log(error)
    }else{
        console.log("Email sent");
        console.log(info.response);
    }
});