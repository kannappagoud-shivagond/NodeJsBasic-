//http
const http = require("http");

const server=http.createServer((req,resp)=>{
//req: request process
//resp: for writting response
resp.writeHead(200, { "content-type": "text/html"});
resp.write("<h1>wow this is response from first server</h1>");
resp.write("<h2>Ok Nice work </h2>");
resp.write("<button> Click me </button>");
resp.end("Ok See u later");
});
server.listen(8080);